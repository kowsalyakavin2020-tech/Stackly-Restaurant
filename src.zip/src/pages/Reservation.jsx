import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";

function Reservation() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Book A Table"
        subtitle="Reserve your table and enjoy an unforgettable dining experience."
      />

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">

          <div className="grid lg:grid-cols-2 gap-12">

            <div className="bg-white p-8 rounded-2xl shadow-lg">

              <h2 className="text-3xl font-bold mb-8">
                Reservation Form
              </h2>

              <form className="space-y-5">

                <input
                  type="text"
                  placeholder="Full Name"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <input
                  type="email"
                  placeholder="Email Address"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <input
                  type="tel"
                  placeholder="Phone Number"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <input
                  type="date"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <input
                  type="time"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <input
                  type="number"
                  placeholder="Number of Guests"
                  className="w-full border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-orange-500"
                />

                <button
                  type="submit"
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-semibold transition"
                >
                  Book Now
                </button>

              </form>

            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg">

              <h2 className="text-3xl font-bold mb-6">
                Opening Hours
              </h2>

              <div className="space-y-4 text-gray-700">

                <p>Monday - Friday : 9:00 AM - 10:00 PM</p>
                <p>Saturday : 10:00 AM - 11:00 PM</p>
                <p>Sunday : 10:00 AM - 9:00 PM</p>

              </div>

              <div className="mt-10">

                <h3 className="text-2xl font-bold mb-4">
                  Contact
                </h3>

                <p>Email : info@stacklyrestaurant.com</p>
                <p>Phone : +91 98765 43210</p>
                <p>Location : Chennai, Tamil Nadu</p>

              </div>

            </div>

          </div>

        </div>
      </section>

      <Footer />
    </>
  );
}

export default Reservation;