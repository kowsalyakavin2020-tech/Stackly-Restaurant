import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";
import { blogs } from "../data/blogs";

function Blog() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Our Blog"
        subtitle="Latest food stories, recipes and restaurant updates."
      />

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">

          <div className="grid gap-8 md:grid-cols-3">
            {blogs.map((blog) => (
              <div
                key={blog.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden"
              >
                <img
                  src={blog.image}
                  alt={blog.title}
                  className="w-full h-60 object-cover"
                />

                <div className="p-6">
                  <p className="text-orange-500 font-semibold">
                    {blog.date}
                  </p>

                  <h2 className="text-2xl font-bold mt-3">
                    {blog.title}
                  </h2>

                  <p className="mt-4 text-gray-600 leading-7">
                    {blog.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      <Footer />
    </>
  );
}

export default Blog;