import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";
import { faqs } from "../data/faq";

function FAQ() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Frequently Asked Questions"
        subtitle="Find answers to the most common questions."
      />

      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6">

          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg p-6 mb-6"
            >
              <h2 className="text-xl font-bold text-gray-900">
                {faq.question}
              </h2>

              <p className="mt-4 text-gray-600 leading-7">
                {faq.answer}
              </p>
            </div>
          ))}

        </div>
      </section>

      <Footer />
    </>
  );
}

export default FAQ;