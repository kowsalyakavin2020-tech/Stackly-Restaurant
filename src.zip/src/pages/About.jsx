import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";
import HomeAbout from "../components/home/HomeAbout";
import { statistics } from "../data/statistics";

function About() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="About Us"
        subtitle="Learn more about Stackly Restaurant and our passion for delicious food."
      />

      <HomeAbout />

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">

          <div className="grid md:grid-cols-3 gap-8 text-center">

  {statistics.map((item) => (
    <div
      key={item.id}
      className="bg-white p-8 rounded-2xl shadow-lg"
    >
      <h2 className="text-4xl font-bold text-orange-600">
        {item.value}
      </h2>

      <p className="mt-3 text-gray-600">
        {item.label}
      </p>
    </div>
  ))}

</div>

        </div>
      </section>

      <Footer />
    </>
  );
}

export default About;