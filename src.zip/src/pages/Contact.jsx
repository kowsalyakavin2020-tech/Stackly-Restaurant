import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";

function Contact() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Contact Us"
        subtitle="We'd love to hear from you. Get in touch with Stackly Restaurant."
      />

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">

          <div className="grid lg:grid-cols-2 gap-12">

            <div className="bg-white rounded-2xl shadow-lg p-8">

              <h2 className="text-3xl font-bold mb-8">
                Send Us A Message
              </h2>

              <form className="space-y-5">

                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none"
                />

                <input
                  type="email"
                  placeholder="Email Address"
                  className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none"
                />

                <input
                  type="text"
                  placeholder="Subject"
                  className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none"
                />

                <textarea
                  rows="6"
                  placeholder="Your Message"
                  className="w-full border rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none resize-none"
                ></textarea>

                <button
                  type="submit"
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white py-4 rounded-xl font-semibold transition"
                >
                  Send Message
                </button>

              </form>

            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">

              <h2 className="text-3xl font-bold mb-8">
                Contact Information
              </h2>

              <div className="space-y-6 text-gray-700">

                <div>
                  <h3 className="font-bold text-lg">Address</h3>
                  <p>123 Food Street, Chennai, Tamil Nadu</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Phone</h3>
                  <p>+91 98765 43210</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Email</h3>
                  <p>info@stacklyrestaurant.com</p>
                </div>

                <div>
                  <h3 className="font-bold text-lg">Working Hours</h3>
                  <p>Mon - Sun : 9:00 AM - 10:00 PM</p>
                </div>

              </div>

            </div>

          </div>

        </div>
      </section>

      <Footer />
    </>
  );
}

export default Contact;