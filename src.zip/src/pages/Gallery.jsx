import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";
import GallerySection from "../components/home/GallerySection";

function Gallery() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Gallery"
        subtitle="Explore our restaurant, delicious dishes and memorable moments."
      />

      <GallerySection />

      <Footer />
    </>
  );
}

export default Gallery;