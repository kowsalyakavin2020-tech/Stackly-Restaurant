import Navbar from "../components/layout/Navbar";
import Footer from "../components/layout/Footer";
import PageBanner from "../components/common/PageBanner";
import PopularDishes from "../components/home/PopularDishes";

function Menu() {
  return (
    <>
      <Navbar />

      <PageBanner
        title="Our Menu"
        subtitle="Discover our delicious dishes prepared with fresh ingredients."
      />

      <PopularDishes />

      <Footer />
    </>
  );
}

export default Menu;