import { Link } from "react-router-dom";

function NotFound() {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gray-50 px-6">
      <div className="text-center max-w-xl">

        <h1 className="text-8xl font-extrabold text-orange-500">
          404
        </h1>

        <h2 className="text-4xl font-bold text-gray-900 mt-6">
          Page Not Found
        </h2>

        <p className="mt-5 text-gray-600 leading-7">
          Sorry, the page you are looking for doesn't exist or has been
          moved. Please return to the homepage.
        </p>

        <Link
          to="/"
          className="inline-block mt-8 bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-full font-semibold transition duration-300"
        >
          Back To Home
        </Link>

      </div>
    </section>
  );
}

export default NotFound;