import { Link } from "react-router-dom";
import { motion } from "framer-motion";

import aboutImg from "../../assets/images/about/about-1.webp";

function HomeAbout() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <div className="grid lg:grid-cols-2 gap-16 items-center">

          <motion.div
            initial={{ opacity: 0, x: -70 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img
              src={aboutImg}
              alt="About Restaurant"
              className="rounded-3xl shadow-2xl"
            />

            <div className="absolute -bottom-8 -right-8 bg-orange-500 text-white rounded-2xl p-8 shadow-xl">
              <h2 className="text-4xl font-bold">20+</h2>
              <p>Years Experience</p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 70 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <span className="inline-block bg-orange-100 text-orange-600 px-5 py-2 rounded-full font-semibold mb-6">
              About Us
            </span>

            <h2 className="text-5xl font-bold text-gray-900 leading-tight">
              We Create Delicious Food For Every Occasion
            </h2>

            <p className="mt-8 text-gray-600 leading-8">
              At Stackly Restaurant, we believe every meal should become a memorable experience.
              Our chefs prepare every dish using fresh ingredients, premium recipes and authentic
              cooking techniques.
            </p>

            <p className="mt-6 text-gray-600 leading-8">
              From family dinners to corporate events, we proudly serve thousands of happy
              customers with passion and excellence.
            </p>

            <div className="grid grid-cols-2 gap-6 mt-10">

              <div className="bg-orange-50 rounded-2xl p-6">
                <h3 className="text-xl font-bold text-gray-900">
                  Fresh Ingredients
                </h3>

                <p className="mt-3 text-gray-600">
                  Every dish is prepared using fresh and premium quality ingredients.
                </p>
              </div>

              <div className="bg-orange-50 rounded-2xl p-6">
                <h3 className="text-xl font-bold text-gray-900">
                  Expert Chefs
                </h3>

                <p className="mt-3 text-gray-600">
                  Our experienced chefs deliver authentic taste with perfection.
                </p>
              </div>

            </div>

            <Link
              to="/about"
              className="inline-block mt-10 bg-orange-500 hover:bg-orange-600 text-white px-8 py-4 rounded-full font-semibold transition"
            >
              Learn More
            </Link>

          </motion.div>

        </div>

      </div>
    </section>
  );
}

export default HomeAbout;