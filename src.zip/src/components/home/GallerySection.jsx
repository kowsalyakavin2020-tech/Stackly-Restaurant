import SectionTitle from "../common/SectionTitle";
import Button from "../common/Button";
import { galleryImages } from "../../data/gallery";



function GallerySection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">

        <SectionTitle
          subtitle="Gallery"
          title="A Glimpse Of Our Restaurant"
          description="Explore our delicious dishes, beautiful interiors and memorable dining moments."
        />

        <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
          {galleryImages.map((image, index) => (
            <div
              key={index}
              className="overflow-hidden rounded-2xl shadow-lg group"
            >
              <img
                src={image}
                alt={`Gallery ${index + 1}`}
                className="w-full h-56 object-cover transition duration-500 group-hover:scale-110"
              />
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <Button to="/gallery">
            View Full Gallery
          </Button>
        </div>

      </div>
    </section>
  );
}

export default GallerySection;