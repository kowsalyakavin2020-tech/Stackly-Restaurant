import Button from "../common/Button";

import reservationImg from "../../assets/images/reservation/reservation-1.webp";

function ReservationCTA() {
  return (
    <section className="py-20 bg-orange-50">
      <div className="max-w-7xl mx-auto px-6">

        <div className="grid lg:grid-cols-2 gap-12 items-center">

          <div>
            <span className="inline-block bg-orange-100 text-orange-600 px-5 py-2 rounded-full font-semibold">
              Reservation
            </span>

            <h2 className="text-5xl font-bold text-gray-900 mt-6 leading-tight">
              Reserve Your Table Today
            </h2>

            <p className="mt-6 text-gray-600 leading-8">
              Enjoy a memorable dining experience with your family and
              friends. Book your table in advance and let us serve you
              the finest dishes prepared by our expert chefs.
            </p>

            <Button
              to="/reservation"
              className="mt-8"
            >
              Book A Table
            </Button>
          </div>

          <div>
            <img
              src={reservationImg}
              alt="Reservation"
              className="rounded-3xl shadow-2xl w-full h-[500px] object-cover"
            />
          </div>

        </div>

      </div>
    </section>
  );
}

export default ReservationCTA;