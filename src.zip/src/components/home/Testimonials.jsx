import SectionTitle from "../common/SectionTitle";
import { testimonials } from "../../data/testimonials";

function Testimonials() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <SectionTitle
          subtitle="Testimonials"
          title="What Our Customers Say"
          description="Thousands of happy customers love our food and service."
        />

        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="bg-gray-50 rounded-2xl shadow-lg p-8 text-center"
            >
              <img
                src={item.image}
                alt={item.name}
                className="w-24 h-24 rounded-full object-cover mx-auto"
              />

              <h3 className="text-xl font-bold mt-5">
                {item.name}
              </h3>

              <p className="text-yellow-500 mt-2">
                ⭐⭐⭐⭐⭐
              </p>

              <p className="text-gray-600 leading-7 mt-5">
                "{item.review}"
              </p>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default Testimonials;