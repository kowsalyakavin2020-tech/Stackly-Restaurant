import SectionTitle from "../common/SectionTitle";
import Button from "../common/Button";
import { blogs } from "../../data/blogs";

function BlogPreview() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <SectionTitle
          subtitle="Latest Blog"
          title="News & Articles"
          description="Read our latest food stories, recipes and restaurant updates."
        />

        <div className="grid gap-8 md:grid-cols-3">
          {blogs.map((blog) => (
            <div
              key={blog.id}
              className="bg-gray-50 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition duration-300"
            >
              <img
                src={blog.image}
                alt={blog.title}
                className="w-full h-60 object-cover"
              />

              <div className="p-6">
                <p className="text-orange-500 text-sm font-semibold">
                  {blog.date}
                </p>

                <h3 className="text-2xl font-bold mt-3 text-gray-900">
                  {blog.title}
                </h3>

                <Button
                  to="/blog"
                  className="mt-6"
                >
                  Read More
                </Button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default BlogPreview;