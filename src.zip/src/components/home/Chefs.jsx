import SectionTitle from "../common/SectionTitle";
import { chefs } from "../../data/chefs";

function Chefs() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">

        <SectionTitle
          subtitle="Our Chefs"
          title="Meet Our Expert Chefs"
          description="Our talented chefs prepare every dish with passion and perfection."
        />

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {chefs.map((chef) => (
            <div
              key={chef.id}
              className="bg-gray-50 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition duration-300"
            >
              <img
                src={chef.image}
                alt={chef.name}
                className="w-full h-80 object-cover"
              />

              <div className="p-6 text-center">
                <h3 className="text-2xl font-bold text-gray-900">
                  {chef.name}
                </h3>

                <p className="mt-2 text-orange-500 font-medium">
                  {chef.role}
                </p>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default Chefs;