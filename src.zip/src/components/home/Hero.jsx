import { Link } from "react-router-dom";
import { motion } from "framer-motion";

import heroBg from "../../assets/images/hero/hero-1.webp";
import heroFood from "../../assets/images/hero/hero-2.webp";

function Hero() {
  return (
  <section
    className="relative overflow-hidden bg-cover bg-center"
    style={{
      backgroundImage: `url(${heroBg})`,
    }}
  >
    {/* Overlay */}
    <div className="absolute inset-0 bg-black/70"></div>

    <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-10 pt-28 lg:pt-32 pb-16">

      <div className="grid lg:grid-cols-[1fr_0.9fr] items-center gap-12">

        {/* LEFT CONTENT */}

        <motion.div
          initial={{ opacity: 0, x: -60 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >

          <span className="inline-flex items-center rounded-full bg-orange-600 px-5 py-2 text-sm font-semibold text-white shadow-lg">

            Welcome To Stackly Restaurant

          </span>

          <h1 "mt-6 text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight text-white">

            Experience

            <br />

            <span className="text-orange-500">
              World-Class
            </span>

            <br />

            Dining

          </h1>

          <p className="mt-8 max-w-xl text-lg leading-8 text-gray-300">

            Discover handcrafted dishes prepared with fresh
            ingredients, authentic recipes and unforgettable
            dining experiences created by our expert chefs.

          </p>

          <div className="mt-10 flex flex-wrap gap-5">

            <Link
              to="/menu"
              className="rounded-full bg-orange-600 px-8 py-4 font-semibold text-white transition hover:bg-orange-700"
            >
              Explore Menu
            </Link>

            <Link
              to="/reservation"
              className="rounded-full border-2 border-white px-8 py-4 font-semibold text-white transition hover:bg-white hover:text-black"
            >
              Book Table
            </Link>

          </div>

        </motion.div>
    
        {/* RIGHT IMAGE */}

<motion.div
  initial={{ opacity: 0, x: 60 }}
  animate={{ opacity: 1, x: 0 }}
  transition={{ duration: 0.9 }}
  className="flex justify-center lg:justify-end"
>
  <div className="relative">

    {/* Orange Glow */}

    <div className="absolute -inset-4 rounded-3xl bg-orange-600/20 blur-2xl"></div>

    <img
      src={heroFood}
      alt="Stackly Restaurant"
      className="relative w-full max-w-sm lg:max-w-md" rounded-3xl object-cover shadow-2xl border border-white/10 transition duration-500 hover:scale-[1.02]"
    />

  </div>
</motion.div>

        </div>

        {/* STATS */}

<motion.div
  initial={{ opacity: 0, y: 40 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ delay: 0.5, duration: 0.8 }}
  className="mt-28 grid grid-cols-1 md:grid-cols-3 gap-6"
>

  <div className="rounded-3xl bg-white/10 backdrop-blur-md border border-white/10 p-8 text-center">
    <h3 className="text-5xl font-bold text-orange-500">
      15K+
    </h3>

    <p className="mt-3 text-gray-200">
      Happy Customers
    </p>
  </div>

  <div className="rounded-3xl bg-white/10 backdrop-blur-md border border-white/10 p-8 text-center">
    <h3 className="text-5xl font-bold text-orange-500">
      50+
    </h3>

    <p className="mt-3 text-gray-200">
      Expert Chefs
    </p>
  </div>

  <div className="rounded-3xl bg-white/10 backdrop-blur-md border border-white/10 p-8 text-center">
    <h3 className="text-5xl font-bold text-orange-500">
      20+
    </h3>

    <p className="mt-3 text-gray-200">
      Years Experience
    </p>
  </div>

</motion.div>

      </div>

      
    </section>
  );
}

export default Hero;