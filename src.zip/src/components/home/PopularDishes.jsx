import SectionTitle from "../common/SectionTitle";
import Button from "../common/Button";
import { dishes } from "../../data/dishes";


function PopularDishes() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">

        <SectionTitle
          subtitle="Popular Dishes"
          title="Our Best Selling Foods"
          description="Fresh ingredients, authentic recipes and unforgettable taste."
        />

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {dishes.map((dish) => (
            <div
              key={dish.id}
              className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition"
            >
              <img
                src={dish.image}
                alt={dish.name}
                className="w-full h-56 object-cover"
              />

              <div className="p-5">
                <h3 className="text-xl font-bold">{dish.name}</h3>

                <p className="text-orange-500 font-semibold mt-2">
                  {dish.price}
                </p>

                <p className="mt-2 text-gray-600">{dish.rating}</p>

                <Button to="/menu" className="w-full mt-5">
                  Order Now
                </Button>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}

export default PopularDishes;