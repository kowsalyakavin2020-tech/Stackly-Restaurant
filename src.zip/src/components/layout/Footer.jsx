import { Link } from "react-router-dom";
import logo from "../../assets/logo/stackly-logo.webp";

function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">

      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 lg:grid-cols-4 gap-10">

        {/* Logo */}

        <div>

          <Link to="/" className="flex items-center gap-3">

            <img
              src={logo}
              alt="Stackly Logo"
              className="w-14 h-14"
            />

            <div>
              <h2 className="text-2xl font-bold">
                Stackly
              </h2>

              <p className="text-orange-400 text-sm">
                Restaurant
              </p>
            </div>

          </Link>

          <p className="text-gray-400 mt-6 leading-7">

            Experience delicious food crafted with passion,
            fresh ingredients and unforgettable taste.

          </p>

        </div>

        {/* Quick Links */}

        <div>

          <h3 className="text-xl font-semibold mb-6">
            Quick Links
          </h3>

          <ul className="space-y-3">

            <li><Link to="/">Home</Link></li>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/menu">Menu</Link></li>
            <li><Link to="/gallery">Gallery</Link></li>
            <li><Link to="/reservation">Reservation</Link></li>

          </ul>

        </div>

        {/* Contact */}

        <div>

          <h3 className="text-xl font-semibold mb-6">
            Contact
          </h3>

          <p className="text-gray-400">
            📍 Chennai, Tamil Nadu
          </p>

          <p className="text-gray-400 mt-3">
            📞 +91 98765 43210
          </p>

          <p className="text-gray-400 mt-3">
            ✉ info@stacklyrestaurant.com
          </p>

        </div>

        {/* Opening Hours */}

        <div>

          <h3 className="text-xl font-semibold mb-6">
            Opening Hours
          </h3>

          <p className="text-gray-400">
            Monday - Friday
          </p>

          <p className="mb-3">
            10:00 AM - 10:00 PM
          </p>

          <p className="text-gray-400">
            Saturday - Sunday
          </p>

          <p>
            09:00 AM - 11:00 PM
          </p>

        </div>

      </div>

      <hr className="border-gray-700 my-10" />

      <div className="text-center text-gray-500 text-sm">

        © {new Date().getFullYear()} Stackly Restaurant.
        All Rights Reserved.

      </div>

    </footer>
  );
}

export default Footer;