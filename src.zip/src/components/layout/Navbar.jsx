import { useState, useEffect } from "react";
import { Link, NavLink } from "react-router-dom";
import { HiMenuAlt3, HiX } from "react-icons/hi";
import { motion, AnimatePresence } from "framer-motion";
import { navLinks } from "../../data/navigation";

import logo from "../../assets/logo/stackly-logo.webp";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
          scrolled
            ? "bg-white shadow-md py-4"
            : "bg-white/95 backdrop-blur-md py-4"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">

        <Link to="/" className="flex items-center">
  <img
    src={logo}
    alt="Stackly"
    className="h-14 w-auto object-contain"
  />
</Link>

          <ul className="hidden lg:flex items-center gap-10">

            {navLinks.map((item) => (

              <li key={item.name}>

                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `${
                      isActive
                        ? "text-orange-500"
                        : "text-gray-700"
                    }
                    font-medium
                    hover:text-orange-500
                    transition-all
                    duration-300`
                  }
                >
                  {item.name}
                </NavLink>

              </li>

            ))}

          </ul>

          <Link
            to="/reservation"
            className="hidden lg:inline-flex items-center justify-center bg-orange-600 hover:bg-orange-700 text-white px-7 py-3 rounded-full font-semibold transition-all duration-300"
          >
            Book Table
          </Link>

          <button
            className="lg:hidden text-3xl"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <HiX /> : <HiMenuAlt3 />}
          </button>

        </div>
      </header>

      <AnimatePresence>

        {isOpen && (

          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ duration: 0.3 }}
            className="fixed top-0 right-0 w-72 h-screen bg-white shadow-2xl z-[60] lg:hidden"
          >

            <div className="flex items-center justify-between p-6 border-b">

              <h2 className="font-bold text-xl">
                Menu
              </h2>

              <button
                onClick={() => setIsOpen(false)}
                className="text-3xl"
              >
                <HiX />
              </button>

            </div>

            <div className="flex flex-col">

              {navLinks.map((item) => (

                <NavLink
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={({ isActive }) =>
                    `px-6 py-4 border-b ${
                      isActive
                        ? "text-orange-500 bg-orange-50"
                        : "text-gray-700"
                    }`
                  }
                >
                  {item.name}
                </NavLink>

              ))}

              <Link
                to="/reservation"
                onClick={() => setIsOpen(false)}
                className="m-6 bg-orange-500 text-white text-center py-3 rounded-full"
              >
                Book Table
              </Link>

            </div>

          </motion.div>

        )}

      </AnimatePresence>
    </>
  );
}

export default Navbar;