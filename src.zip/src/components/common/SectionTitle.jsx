import { motion } from "framer-motion";

function SectionTitle({
  subtitle,
  title,
  description,
  center = true,
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      className={center ? "text-center mb-14" : "mb-14"}
    >
      <span className="inline-block bg-orange-100 text-orange-600 px-5 py-2 rounded-full font-semibold mb-5">
        {subtitle}
      </span>

      <h2 className="text-4xl lg:text-5xl font-bold text-gray-900">
        {title}
      </h2>

      {description && (
        <p className="mt-6 text-gray-600 leading-8 max-w-2xl mx-auto">
          {description}
        </p>
      )}
    </motion.div>
  );
}

export default SectionTitle;