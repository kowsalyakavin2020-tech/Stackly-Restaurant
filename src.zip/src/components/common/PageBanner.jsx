import { motion } from "framer-motion";

function PageBanner({
  title,
  subtitle = "",
  background = "",
}) {
  return (
    <section
      className="relative h-[350px] flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage: background
          ? `url(${background})`
          : "linear-gradient(rgba(0,0,0,.7), rgba(0,0,0,.7))",
      }}
    >
      <div className="absolute inset-0 bg-black/50"></div>

      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="relative z-10 text-center px-6"
      >
        <h1 className="text-5xl lg:text-6xl font-bold text-white">
          {title}
        </h1>

        {subtitle && (
          <p className="mt-5 text-lg text-gray-200 max-w-2xl mx-auto">
            {subtitle}
          </p>
        )}
      </motion.div>
    </section>
  );
}

export default PageBanner;