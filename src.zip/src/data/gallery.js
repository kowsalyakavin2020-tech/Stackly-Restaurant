import gallery1 from "../assets/images/gallery/gallery-1.webp";
import gallery2 from "../assets/images/gallery/gallery-2.webp";
import gallery3 from "../assets/images/gallery/gallery-3.webp";
import gallery4 from "../assets/images/gallery/gallery-4.webp";
import gallery5 from "../assets/images/gallery/gallery-5.webp";
import gallery6 from "../assets/images/gallery/gallery-6.webp";
import gallery7 from "../assets/images/gallery/gallery-7.webp";
import gallery8 from "../assets/images/gallery/gallery-8.webp";

export const galleryImages = [
  gallery1,
  gallery2,
  gallery3,
  gallery4,
  gallery5,
  gallery6,
  gallery7,
  gallery8,
];